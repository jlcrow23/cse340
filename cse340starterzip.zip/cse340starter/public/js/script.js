const toggleMenu = () => {
    document.querySelector('#menu').classList.toggle('open');
}